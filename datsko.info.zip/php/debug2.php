<?php
session_start();
require_once("db.php");
require_once("kernel_1_1.php");
//$k = new kernel;
// f($_REQUEST['type']);
?>
