<?php
class config{
	var $dbhost = 'localhost';
	var $dbname = 'datsko';
	var $dbuser = 'root';
	var $dbpass = '1';
	var $site = 'http://127.0.0.1/datsko.info/';
}
?>